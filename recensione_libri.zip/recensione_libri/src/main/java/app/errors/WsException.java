package app.errors;

public class WsException extends Exception {

	public WsException(String message) {
		super(message);
	}
}
